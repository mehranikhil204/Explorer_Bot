#!/usr/bin/env python


#import rospy and msg libraries
import rospy
from std_msgs.msg import *

operation_list=["add","sub","mul","div"]	#operation list

result = 0
n1=0    	#initialize number1, number2, number3 to be 0,1 and 2 respectively and increment each number by 1 after each iteration
n2=1
n3=2
i=0

def Print_result(temp): #callback function for the result
	
	global n1,n2,n3,i   # Global variables declaration

        result= temp.data   #data from the subscribed messager should be stored in variable 'result'

	x1="("+str(n1)+"+"+str(n2)+") "+operation_list[i]+" "+str(n3)+" = "	# Output Format		
	
	rospy.loginfo(x1+str(result))

	n1 = n1 + 1	    # increment of number1, number2, number3		

	n2 = n2 + 1

	n3 = n3 + 1

	if i==3:           # change in the index of operation_list for changing operations
	    i=0
 	else:
	    i=i+1	
	

rospy.init_node('NODE1')   #Init node NODE1		

pub=rospy.Publisher('number1',Int32,queue_size=1)  #publisher of the topic number1 #data-type integer

pub1=rospy.Publisher('number2',Int32,queue_size=1) #publisher of the topic number2 #data-type integer

pub2=rospy.Publisher('number3',Int32,queue_size=1) #publisher of the topic number3  #data-type integer

pub3=rospy.Publisher('operator',String,queue_size=1) #publisher of the topic operator #data-type string

sub=rospy.Subscriber('result',Float32,Print_result,queue_size=1) #Subscriber for the result topic #data-type float

rate=rospy.Rate(1) #set rospy rate as 1msg/sec

while not rospy.is_shutdown(): #until rospy is not shutdown
	
	pub.publish(n1) #publish num1 over the topic number1(n1 is the object name here)

	pub1.publish(n2) #publish num2 over the topic number1(n2 is the object name here)

	pub2.publish(n3) #publish num3 over the topic number1(n3 is the object name here)

	pub3.publish(operation_list[i]) # publish operation over the topic operator(operation_list[i] is the argument here)
	
	rate.sleep() #do nothing for specified delay in rate.

