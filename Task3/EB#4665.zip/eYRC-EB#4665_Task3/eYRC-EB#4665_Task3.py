#!/usr/bin/env python

'''
* Team Id          : eYRC-EB#4665
* Author List      : Nikhil Mehra, Hitesh Kansal
* Filename         : eYRC-EB#4665_Task3.py
* Theme            : Explorer Bot
* Functions        : Print_result
* Global Variables : temp_store, clock_time
'''

# import rospy, time, standard msg and visualization msg libraries
import rospy
import time
from std_msgs.msg import *
from visualization_msgs.msg import *

temp_store = 0  # Temporary Storage of aruco marker ID

clock_time = 0  # Stores clock time

'''
* Function Name : Print_result
* Input         : temp - Data of datatupe 'Marker' coming from subscriber 'Estimated Marker'
* Output        : This function does not return anything however it prints data on the console.
* Logic         : Required data 'ID' is taken from input variable 'temp' then the data is identified with the help of a dictionary 'marker_disc'. After identification the result is printed on the console ONLY ONCE when one aruco marker is shown in front of the camera.
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'Estimated Marker'. 
'''

def Print_result(temp):  # callback function for the result

	global temp_store, clock_time  # Global variable declaration

	marker_list = [200,201,202,203,204,205,206,207,208,209,210,211,212,213,214] # List of all authentic ID markers

	marker_dic = {200:'Sandy',201:'Clay',202:'Slilty sand',203:'Rain Water',204:'Ice',205:'Snow water',206:'Sedimentary',207:'Metamorphic',208:'Igneous',209:'Oxides',210:'Carbonates',211:'Phosphates',212:'Sulfides',213:'Native Element',214:'Silicates'}  # Dictionary used for identification of ID Markers	
	
	result = temp.id  # store data in result variable
	
	if result != temp_store:  # Compares value of data with previous data acquired

 		temp_store = result # Store data in the temporary variable used for comparing current data
 	
		if result in marker_list:  # Checks if ID is authentic
		
			rospy.loginfo('Marker ID '+str(result)+' : '+marker_dic[result])  # Prints details of the ID after identification

		else:

			rospy.loginfo('Marker ID '+str(result)+' : No record found of this marker') # Prints details if ID is not authentic
	
	elif (result == temp_store):

		time1 = time.clock()*1000  # Store clock time when same ID is read again

		if ((time1 - clock_time) >= 5): # Compares current clock time with last clock time when subscribed

			temp_store = 0  # If there is a gap between clock times meaning the user is switching aruco marker or now will shown another aruco marker
	
	clock_time = time.clock()*1000 # Store clock time when any data is subscribed

rospy.init_node('NODE1') # Initialization of node 'NODE1'

sub=rospy.Subscriber('/Estimated_marker',Marker,Print_result,queue_size=1) # Subscribe data from subscriber 'Estimated Marker' with datatype 'Marker' and then call the function 'Print_result'

rate=rospy.Rate(1) # set rospy rate as 1msg/sec

while not rospy.is_shutdown():  # until rospy is shutdown
	
	rate.sleep() # do nothing for specified delay in rate
