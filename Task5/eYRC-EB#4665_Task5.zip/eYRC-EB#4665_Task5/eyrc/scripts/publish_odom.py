#!/usr/bin/env python

'''
* Team Id          : eYRC-EB#4665
* Author List      : Nikhil Mehra, Hitesh Kansal, Aditya Goswami
* Filename         : publish_odom.py
* Theme            : Explorer Bot
* Functions        : assign_velx,assign_vely,assign_angz,assign_x,assign_y,assign_th
* Global Variables : velx,vely,velth,distx,disty,theta
'''

# import rospy, time, standard msg, geometry msg and navigation msg libraries
import rospy
import tf
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3
from std_msgs.msg import *

velx = 0   # velocity in x axis

velth = 0   # angular velocity in z axis

distx = 0   # distance travelled in x axis

disty = 0   # distance travelled in y axis

theta = 0   # angle turned in z axis

'''
* Function Name : assign_velx
* Input         : temp - Data of datatype 'float32' coming from subscriber 'velx'
* Output        : This function does not return anything.
* Logic         : This function just assign values to the global variable.  
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'velx'. 
'''

def assign_velx(temp):  # callback function for the subscriber velx

	global velx   # Global variable declaration

	velx = temp.data   # Storing data in the variable for further use.

'''
* Function Name : assign_angz
* Input         : temp - Data of datatype 'float32' coming from subscriber 'angz'
* Output        : This function does not return anything.
* Logic         : This function just assign values to the global variable.  
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'angz'. 
'''
 
def assign_angz(temp):   # callback function for the subscriber angz

	global velth   # Global variable declaration

	velth = temp.data   # Storing data in the variable for further use.

'''
* Function Name : assign_x
* Input         : temp - Data of datatype 'float32' coming from subscriber '/x'
* Output        : This function does not return anything.
* Logic         : This function just assign values to the global variable.  
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber '/x'. 
'''

def assign_x(temp):   # callback function for the subscriber /x

	global distx   # Global variable declaration

	distx = temp.data   # Storing data in the variable for further use.

'''
* Function Name : assign_y
* Input         : temp - Data of datatype 'float32' coming from subscriber '/y'
* Output        : This function does not return anything.
* Logic         : This function just assign values to the global variable.  
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber '/y'. 
'''

def assign_y(temp):   # callback function for the subscriber /x

	global disty  # Global variable declaration

	disty = temp.data   # Storing data in the variable for further use.

'''
* Function Name : assign_th
* Input         : temp - Data of datatype 'float32' coming from subscriber 'angle'
* Output        : This function does not return anything.
* Logic         : This function just assign values to the global variable.  
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'angle'. 
'''

def assign_th(temp):   # callback function for the subscriber /x

	global theta  # Global variable declaration

	theta = temp.data   # Storing data in the variable for further use.


rospy.init_node('odometry_publisher')    # Initialization of node 'odometry_publisher'

sub1 = rospy.Subscriber('/velx', Float32 , assign_velx, queue_size=5)   # Subscribe data from subscriber 'velx' with datatype 'float32' and then call the function 'assign_velx'

sub3 = rospy.Subscriber('/angz', Float32, assign_angz, queue_size=5)    # Subscribe data from subscriber 'angz' with datatype 'float32' and then call the function 'assign_angz'

sub4 = rospy.Subscriber('/x', Float32, assign_x, queue_size=5)    # Subscribe data from subscriber '/x' with datatype 'float32' and then call the function 'assign_x'

sub5 = rospy.Subscriber('/y', Float32, assign_y, queue_size=5)    # Subscribe data from subscriber '/y' with datatype 'float32' and then call the function 'assign_y'

sub6 = rospy.Subscriber('/angle', Float32, assign_th, queue_size=5)    # Subscribe data from subscriber 'angle' with datatype 'float32' and then call the function 'assign_th'

odom_pub = rospy.Publisher("odom", Odometry, queue_size=50)   # Publish data to node 'odom' with datatype 'Odometry'
odom_broadcaster = tf.TransformBroadcaster()   # Intialize transform broadcaster

x = 0.0   # x coordinate
y = 0.0   # y coordinate
th = 0.0  # angle in z direction

vx = 0.0  # velocity in x axis
vy = 0.0  # velocity in y axis
vth = 0.0 # angular velocity in z axis

r = rospy.Rate(10.0)   # # set rospy rate as 5msg/sec


while not rospy.is_shutdown():   # until rospy is shutdown
    current_time = rospy.Time.now()  # Store current time in ros
     
    vx = velx   # assign linear velocity in x axis from global variable velx
    vy = 0   # assign linear velocity in y axis from global variable vely
    vth = velth	# assign angular velocity in z axis from global variable velth

    x += distx  # increment or decrement in x coordinate
    y += disty  # increment or decrement in y coordinate
    th += theta # increment or decrement in angle in z direction

    # since all odometry is 6DOF we'll need a quaternion created from yaw
    odom_quat = tf.transformations.quaternion_from_euler(0, 0, th)

    # first, we'll publish the transform over tf
    odom_broadcaster.sendTransform(
        (x, y, 0.),
        odom_quat,
        current_time,
        "base_link",
        "odom"
    )

    # next, we'll publish the odometry message over ROS
    odom = Odometry()
    odom.header.stamp = current_time
    odom.header.frame_id = "odom"

    # set the position
    odom.pose.pose = Pose(Point(x, y, 0.), Quaternion(*odom_quat))

    # set the velocity
    odom.child_frame_id = "base_link"
    odom.twist.twist = Twist(Vector3(vx, vy, 0), Vector3(0, 0, vth))

    # publish the message
    odom_pub.publish(odom)
 
    r.sleep()
