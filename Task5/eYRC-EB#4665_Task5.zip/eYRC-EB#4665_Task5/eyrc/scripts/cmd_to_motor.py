#!/usr/bin/env python

'''
* Team Id          : eYRC-EB#4665
* Author List      : Aditya goswami, Nikhil Mehra, Hitesh Kansal
* Filename         : cmd_to_motor.py
* Theme            : Explorer Bot
* Functions        : assign_values
* Global Variables : wheel_vel, wheel_angular
'''

# import rospy, time, standard msg and geometry msg libraries 
import rospy
from std_msgs.msg import *
from geometry_msgs.msg import Twist

wheel_vel = 0.0  # Initial velocity of global variable wheel_vel

wheel_angular = 0.0  # Initial angular velocity of global variable wheel_angular

'''
* Function Name : assign_values
* Input         : temp - Data of datatype 'twist' coming from subscriber 'cmd_vel'
* Output        : This function does not return anything however it publishes values to their respective topics.
* Logic         : This function calculates bit values (0 - 255) from the data subscribed from cmd_vel. If bit value is less than 110 this function publishes 110 bit value to the topics. Otherwise this function publishes the calculated bit value.  
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'cmd_vel'. 
'''

def assign_values(temp):  # callback function for the subscriber cmd_vel

	global wheel_vel, wheel_angular  # Global variable declaration

	linear_vel = temp.linear.x  # store data in linear_vel variable

	angular_vel = temp.angular.z  # store data in angular_vel variable

	wheel_vel = linear_vel  # store data in wheel_vel variable

	wheel_angular = angular_vel  # store data in wheel_angular variable

	if (wheel_angular != 0 and wheel_angular < 0):  # Checks if wheel_angular is negative

		digital_value = int((0.185*wheel_angular*255)/0.3401)  # store integer data in digital_value variable 
	
		if digital_value < 150:  # Check if digital_value is less than 110

			pub1.publish(-150)  # Publish the digital value -110 with pub1 publisher 

			pub3.publish(0)  # Publish the digital value 0 with pub3 publisher

		else:
				
			pub1.publish(int((0.185*wheel_angular*255)/0.3401))  # Publish the integer digital value with pub1 publisher

			pub3.publish(0)  # Publish the integer digital value 0 with pub3 publisher
	
	elif (wheel_angular != 0 and wheel_angular > 0):  # Checks if wheel_angular is positive

		digital_value = int((0.185*wheel_angular*255)/0.3401)  # store integer data in digital_value variable

		if digital_value < 150:  # Check if digital_value is less than 110

			pub1.publish(150)  # Publish the digital value 110 with pub1 publisher

			pub3.publish(0)  # Publish the digital value 0 with pub3 publisher
			
		else:

			pub1.publish(int((0.185*wheel_angular*255)/0.3401))  # Publish the integer digital value with pub1 publisher

			pub3.publish(0)  # Publish the integer digital value 0 with pub3 publisher
	
	elif (linear_vel != 0 and wheel_angular == 0):  # Checks if wheel_angular is zero and linear_vel is not equal to zero

		digital_value = int(((linear_vel*255)/0.3401))  # store integer data in digital_value variable
		if digital_value < 150:  # Check if digital_value is less than 110

			pub3.publish(150)  # Publish the digital value 110 with pub3 publisher
		
			pub1.publish(0)  # Publish the digital value 0 with pub1 publisher

		else:
	
			pub3.publish(int(((linear_vel*255)/0.3401)))  # Publish the integer digital value with pub3 publisher
			
			pub1.publish(0)  # Publish the integer digital value 0 with pub1 publisher

	elif (linear_vel == 0 and wheel_angular == 0):  # Checks if wheel_angular is zero and linear_vel is zero

		pub3.publish(0)  # Publish the digital value 0 with pub3 publisher

		pub1.publish(0)  # Publish the digital value 0 with pub1 publisher

	
rospy.init_node('cmd_to_motor')  # Initialization of node 'cmd_to_motor'

pub1 = rospy.Publisher('turn_vel', Int32, queue_size=5)  # Publish data to publisher 'turn_vel' with datatype 'Int32'

pub3 = rospy.Publisher('forward', Int32, queue_size=5)  # Publish data to publisher 'forward' with datatype 'Int32'

sub1 = rospy.Subscriber('/cmd_vel', Twist, assign_values, queue_size=5)  # Subscribe data from subscriber 'cmd_vel' with datatype 'Twist' and then call the function 'assign_values'

rate = rospy.Rate(1)  # set rospy rate as 1msg/sec

while not rospy.is_shutdown():  # until rospy is shutdown

	rate.sleep()  # do nothing for specified delay in rate
