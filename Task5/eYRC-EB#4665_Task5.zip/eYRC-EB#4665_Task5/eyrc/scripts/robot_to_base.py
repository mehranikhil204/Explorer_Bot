#!/usr/bin/env python

'''
* Team Id          : eYRC-EB#4665
* Author List      : Hitesh Kansal, Nikhil Mehra, Aditya Goswami
* Filename         : robot_to_base.py
* Theme            : Explorer Bot
* Functions        : assign_values_right, assign_values_left, assign_values_gyro, assign_values_time, assign_values_time_gyro
* Global Variables : distr, distl, theta_vel, enfirstR, enfirstL, dtt, dtg, lastgdata, flag, gyro_vel, error
'''

# import math, rospy, standard msg libraries
import math
from math import sin, cos, pi

import rospy
from std_msgs.msg import *

distr = 0.0  # distance travelled by right wheel

distl = 0.0  # distance travelled by left wheel

theta_vel = 0.0  # variable for temporary storage of gyroscope values

enfirstR = 0  # right encoder value from the previous run

enfirstL = 0  # left encoder values from the previous run 

dtt = 0.150  # time b/w two consecutive encoder values

dtg = 0.150  # time b/w two consecutive gyroscope values

lastgdata = 0.0  # gyroscope value from the previous run

flag = 0.0  # variable used to stablize the gyroscope values 

gyro_vel = 0.0  # variable for storage of change in gyroscope values

error = 0.0 # offset variable for gyroscope values

'''
* Function Name : assign_values_right
* Input         : temp - Data of datatype 'Int32' coming from subscriber 'encoder_ticks_right'
* Output        : This function does not return anything.
* Logic         : this function calculates the difference b/w the distance travelled by right wheel from previous run and present run of the function
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'encoder_ticks_right'. 
'''

def assign_values_right(temp):  # callback function for the encoder_ticks_right

	global distr,enfirstR  # Global variable declaration

	enlast = temp.data  # store data in enlast variable

	if enlast < 0:  # Checks if last encoder value is negative

		enlast = 32768 + enlast  # adding 32768 to enlast value

	if enlast == 0 and enfirstR != 0:  # Checks if present encoder value is zero  and previous(enfirstR) is not zero

		distr = 0  # store 0 in distr variable
		enfirstR = 0  # store 0 in enfirstR variable

	else:

		distr = (2*pi*0.0325*(enlast-enfirstR))/(1680)  # calculating distance for right wheel from encoder values

		#rospy.loginfo(str(distr))
		enfirstR = enlast  # store data in enfirstR variable


'''
* Function Name : assign_values_left
* Input         : temp - Data of datatype 'Int32' coming from subscriber 'encoder_ticks_left'
* Output        : This function does not return anything.
* Logic         : this function calculates the difference b/w the distance travelled by left wheel from previous run and present run of the function
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'encoder_ticks_left'. 
'''

def assign_values_left(temp):  # callback function for the encoder_ticks_left

	global distl,enfirstL  # Global variable declaration

	enlast = temp.data  # store data in enlast variable

	if enlast < 0:  # Checks if last encoder value is negative

		enlast = 32768 + enlast  # adding 32768 to enlast value

	if enlast == 0 and enfirstL != 0:  # Checks if last encoder value is zero  and enfirstR is not zero

		distl = 0  # store 0 in distr variable
		enfirstL = 0  # store 0 in enfirstR variable

	else:

		distl = (2*pi*0.0325*(enlast-enfirstL))/(1680)  # calculating distance for right wheel from encoder values
		#rospy.loginfo(str(enlast-enfirstL))
		enfirstL = enlast  # store data in enfirstR variable

'''
* Function Name : assign_values_gyro
* Input         : temp - Data of datatype 'Float32' coming from subscriber 'gyro'
* Output        : This function does not return anything.
* Logic         : this function calculates the difference b/w angle moved by the bot from the previous to present position
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'gyro'. 
'''

def assign_values_gyro(temp):  # callback function for the gyro

	global theta_vel,flag,gyro_vel,lastgdata,error  # Global variable declaration

	theta_vel = temp.data - error  # store data in theta_vel variable
	
	if theta_vel < 0:  # Checks if theta_vel is negative

		theta_vel = 2*pi + theta_vel  # adding 360 to theta_vel value	
	
	if flag == 20:  # Checks if flag is 20
		
		error = theta_vel  # assigntheta_vel to error
		lastgdata = theta_vel - error  # store differnce b/w theta_vel and error in lastgdata variable
		theta_vel = theta_vel - error
		flag = 21

	elif flag < 20:  # Checks if flag is less than or equal to 20 
		
		theta_vel = 0.0 	# store 0 in distr variable	
		flag = flag + 1	 # increment flag by 1	
	
		
	else:  		# Checks if difference b/w lastgdata and theta_vel is positive 
	
		gyro_vel = (lastgdata - theta_vel)  # calculating gyro_vel from lastgdata and theta_vel

		lastgdata = theta_vel  # store theta_vel in lastgdata variable
	
'''

* Function Name : assign_values_time
* Input         : temp - Data of datatype 'Float32' coming from subscriber 'time'
* Output        : This function does not return anything.
* Logic         : this function calculates the change in time b/w two encoder in seconds
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'time'. 


def assign_values_time(temp):  # callback function for the time

	global dtt  # Global variable declaration
	
	dtt = temp.data/1000  # store change in time in seconds 

	if dtt > 0.2:  # Checks if dtt is greater than 0.3

		dtt = 0.1  # assign dtt 0.2
'''
'''
* Function Name : assign_values_time_gyro
* Input         : temp - Data of datatype 'Float32' coming from subscriber 'time_gyro'
* Output        : This function does not return anything.
* Logic         : this function calculates the change in time b/w two gyroscope in seconds
* Example Call  : This function is called automatically when the data is subscribed by the susbcriber 'time_gyro'. 


def assign_values_time_gyro(temp):  # callback function for the time_gyro
	
	global dtg  # Global variable declaration

	dtg = temp.data/1000  # store change in time in seconds

	if dtg > 0.2:  # Checks if dtt is greater than 0.3

		dtg = 0.1  # assign dtt 0.2
'''

rospy.init_node('robot_to_base')  # Initialization of node 'robot_to_base'

sub1 = rospy.Subscriber('/encoder_ticks_right', Int32 , assign_values_right, queue_size=5)  # Subscribe data from subscriber 'encoder_ticks_right' with datatype 'Int32' and then call the function 'assign_values_right'

sub2 = rospy.Subscriber('/encoder_ticks_left', Int32 , assign_values_left, queue_size=5)  # Subscribe data from subscriber 'encoder_ticks_left' with datatype 'Int32' and then call the function 'assign_values_left'

sub3 = rospy.Subscriber('/gyro', Float32, assign_values_gyro, queue_size=5)  # Subscribe data from subscriber 'gyro' with datatype 'Float32' and then call the function 'assign_values_gyro'

'''
sub4 = rospy.Subscriber('/time', Float32, assign_values_time, queue_size=5)  # Subscribe data from subscriber 'time' with datatype 'Float32' and then call the function 'assign_values_time'

sub5 = rospy.Subscriber('/time_gyro', Float32, assign_values_time_gyro, queue_size=5)  # Subscribe data from subscriber 'time_gyro' with datatype 'Float32' and then call the function 'assign_values_time_gyro'
'''

pub1 = rospy.Publisher('/velx', Float32, queue_size=5)  # Publish data to publisher 'velx' with datatype 'Float32'

pub3 = rospy.Publisher('/angz', Float32, queue_size=5)  # Publish data to publisher 'angz' with datatype 'Float32'

pub4 = rospy.Publisher('/x', Float32, queue_size=5)  # Publish data to publisher 'x' with datatype 'Float32'

pub5 = rospy.Publisher('/y', Float32, queue_size=5)  # Publish data to publisher 'y' with datatype 'Float32'

pub6 = rospy.Publisher('/angle', Float32, queue_size=5)  # Publish data to publisher 'angle' with datatype 'Float32'

r = rospy.Rate(10.0)  # set rospy rate as 6msg/sec

while not rospy.is_shutdown():  # until rospy is shutdown

	velr = distr/dtt  # store velocity for right wheel in velr variable

	vell = distl/dtt  # store velocity for left wheel in vell variable

	dtheta = gyro_vel/dtg  # store angular velocity in dtheta variable

	if velr >= 0 and vell>= 0: 

		velx = (velr+vell)/2  # calculating the resultant velocity in x direction 
		
		x = (velx*cos(theta_vel))*dtt  # calculating displacement in x direction
		
		
		 
		y = (velx*sin(theta_vel))*dtt*-1  # calculating displacement in y direction

		th = gyro_vel

		pub1.publish(velx)  # Publish the velocity in x direction with pub1 publisher

		pub3.publish(dtheta)  # Publish the angular velocity with pub3 publisher

		pub4.publish(x)  # Publish the displacement in x direction with pub4 publisher
	
		pub5.publish(y)  # Publish the displacement in y direction with pub5 publisher

		pub6.publish(th)  # Publish the angular velocity with pub6 publisher

		r.sleep()  # do nothing for specified delay in rate
